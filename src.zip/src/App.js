import React, { useState, useEffect } from 'react';
import styled from 'styled-components';
import { GiCircleForest } from "react-icons/gi";
import { FaBars } from "react-icons/fa";
import { IoCloseSharp } from "react-icons/io5";
import "./App.css";

const Container = styled.div`
  display: flex;  
  flex-direction: column;
  align-items: center;
  padding: 0 20px 20px 20px;
`;

const Navbar = styled.nav`
  display: flex;
  justify-content: space-between;
  align-items: center;
  width: 80%;
  background-color: green;
  padding: 6px 20px;
  box-shadow: 5px 4px 8px #fff;
  border-radius: 100px;
  position: relative;

  @media (max-width: 1100px) {
    display: flex;
    align-items: flex-start;
    border-radius: 20px;
  }
`;

const NavItems = styled.div`
  display: flex;
  gap: 20px;

  @media (max-width: 1100px) {
    display: ${props => props.show ? 'flex' : 'none'};
    flex-direction: column;
    width: 100%;
  }
`;

const NavItem = styled.div`
  position: relative;
  color: #fff;
  padding: 10px 20px;
  cursor: pointer;
  &:hover > div {
    display: block;
    margin-left: 100px;
    margin-top: -40px;
  }
`;

const Dropdown = styled.div`
  display: none;
  position: absolute;
  top: 100%;
  left: 0;
  background-color: limegreen;
  min-width: 160px;
  box-shadow: 5px 8px 16px green;
  z-index: 1;
  border-radius: 20px;
  > div {
    color: #fff;
    padding: 10px 20px;
    cursor: pointer;
    &:hover {
      background-color: green;
      margin-left: 20px;
    }
  }
`;

const BurgerMenu = styled(FaBars)`
font-size: 40px;
  display: none;
  color: white;
  cursor: pointer;
  margin-top: 18px;

  @media (max-width: 1100px) {
    display: block;
  }
`;
const BurgerClose = styled(IoCloseSharp)`
font-size: 40px;
  display: none;
  color: white;
  cursor: pointer;
  margin-top: 18px;

  @media (max-width: 1100px) {
    display: block;
  }
`;

const SearchInput = styled.input`
  padding: 10px;
  margin: 20px 0;
  width: 300px;
  font-size: 1em;
  border: 2px solid green;
  color: green;
  border-radius: 5px;
  &::placeholder{
    color: green;
  }
`;

const CardsContainer = styled.div`
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
`;

const Card = styled.div`
  border: 1px solid #ddd;
  border-radius: 15px;
  padding: 20px;
  margin: 10px;
  width: 250px;
  box-shadow: 5px 4px 8px lime;
  background-color: limegreen;
`;

const Name = styled.h2`
  font-size: 1.5em;
  margin: 10px 0;
  color: #fff;
`;

const Info = styled.p`
  color: #666;
  color: #fff;
`;

const convertSpeedToKmh = (mph) => {
  const speed = parseFloat(mph);
  if (isNaN(speed)) return 'None';
  return (speed * 1.60934).toFixed(2) + ' km/h';
};

const AnimalCard1 = ({ name, speed, location, diet, lifespan, favoriteFood }) => (
  <Card>
    <Name>{name}</Name>
    {speed && <Info><strong>Top Speed:</strong> {convertSpeedToKmh(speed)}</Info>}
    {location && <Info><strong>Location:</strong> {location}</Info>}
    {diet && <Info><strong>Diet:</strong> {diet}</Info>}
    {lifespan && <Info><strong>Lifespan:</strong> {lifespan}</Info>}
    {favoriteFood && <Info><strong>Favorite Food:</strong> {favoriteFood}</Info>}
  </Card>
);

const App = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [animals, setAnimals] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [showMenu, setShowMenu] = useState(false);

  const handleSearchChange = (event) => {
    setSearchTerm(event.target.value);
  };

  const fetchAnimals = (animalName) => {
    if (animalName === '') return;

    setLoading(true);
    setError('');
    setShowMenu(false)

    fetch(`https://api.api-ninjas.com/v1/animals?name=${animalName}`, {
      headers: { 'X-Api-Key': 'iWJNPuK5vzVIT6OaUZO7Xw==sRzi9uTuT8pmkX91' }
    })
      .then((response) => {
        if (!response.ok) {
          throw new Error('Ma`lumot Topilmadi');
        }
        return response.json();
      })
      .then((data) => {
        setAnimals(data);
        setLoading(false);
      })
      .catch((err) => {
        setError(err.message);
        setLoading(false);
      });
  };

  const handleKeyDown = (event) => {
    if (event.key === 'Enter') {
      fetchAnimals(searchTerm);
      setSearchTerm('')
    }
  };

  useEffect(() => {
    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [searchTerm]);

  return (
    <Container>
      <Navbar>
        {showMenu?<BurgerClose onClick={() => setShowMenu(!showMenu)} />:<BurgerMenu onClick={() => setShowMenu(!showMenu)} />}
        <NavItems show={showMenu}>
          <NavItem>Home</NavItem>
          <NavItem>
            Animals
            <Dropdown>
              <div onClick={() => fetchAnimals('Rabbit')}>Rabbit</div>
              <div onClick={() => fetchAnimals('Lion')}>Lion</div>
              <div onClick={() => fetchAnimals('Tiger')}>Tiger</div>
            </Dropdown>
          </NavItem>
          <NavItem>About</NavItem>
          <NavItem>Contact</NavItem>
        </NavItems>
      <GiCircleForest className='forest_icon'/>
      </Navbar>
      <SearchInput 
        type="text" 
        placeholder="Search an animal" 
        value={searchTerm} 
        onChange={handleSearchChange}
      />
      {loading && <p>Loading...</p>}
      {error && <p>{error}</p>}
      <CardsContainer>
        {animals.map((animal) => (
          <AnimalCard1 
            key={animal.name}
            name={animal.name}
            speed={animal.characteristics.top_speed}
            location={animal.locations.join(', ')}
            diet={animal.characteristics.diet}
            lifespan={animal.characteristics.lifespan}
            favoriteFood={animal.characteristics.favorite_food}
          />
        ))}
      </CardsContainer>
    </Container>
  );
};

export default App;
