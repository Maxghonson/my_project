export const movies=[
    {title:'Avatar',year:2009,rating:7.6},
    {title:'F9',year:2019,rating:6.9},
    {title:'Venom',year:2010,rating:5.6},
    {title:'Avengers',year:2012,rating:8.2},
    {title:'Kung fu Panda 4',year:2024,rating:9.4}
]